# TOXIC YOBBY Pair Site (PHP)

## Requirements
- PHP 7.4+ hosting
- Node.js 18+ installed on server (for Baileys backend)
- `exec()` function enabled in PHP

## Setup

1. Upload all files to your PHP hosting root
2. Run `npm install` in the root directory to install Baileys dependencies
3. Make sure `sessions/` directory is writable (chmod 755)
4. The site should work automatically

## How It Works

- `index.php` — Main pairing UI (premium dark theme)
- `api/pair.php` — Starts pairing session, spawns Node.js in background
- `api/status.php` — Polls session status from JSON file
- `server.js` — Node.js Baileys worker that connects to WhatsApp
- `sessions/` — Temporary session data files

## Notes
- Session files auto-cleanup after 5 minutes
- Node.js must be available in server PATH
- The `exec()` PHP function must be enabled for background process spawning
