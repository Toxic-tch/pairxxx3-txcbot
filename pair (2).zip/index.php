<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TOXIC YOBBY - Pair Your WhatsApp</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&family=JetBrains+Mono:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Inter',sans-serif;background:#060d1b;color:#f0f4ff;min-height:100vh;overflow-x:hidden}
        .bg-fx{position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:0}
        .orb{position:absolute;border-radius:50%;filter:blur(100px);opacity:.5;animation:orbF 8s ease-in-out infinite}
        .orb1{top:-20%;left:-10%;width:500px;height:500px;background:rgba(59,130,246,.08)}
        .orb2{bottom:-10%;right:-15%;width:450px;height:450px;background:rgba(6,182,212,.06);animation-delay:3s}
        .orb3{top:50%;left:50%;transform:translate(-50%,-50%);width:600px;height:600px;background:rgba(30,64,175,.04);animation-delay:5s}
        @keyframes orbF{0%,100%{transform:translate(0,0) scale(1)}33%{transform:translate(20px,-20px) scale(1.05)}66%{transform:translate(-10px,15px) scale(.95)}}
        .wrap{position:relative;z-index:1;max-width:440px;margin:0 auto;padding:0 16px 24px;display:flex;flex-direction:column;align-items:center}
        .topbar{position:relative;z-index:10;display:flex;align-items:center;justify-content:space-between;padding:12px 16px;max-width:500px;margin:0 auto;width:100%}
        .topbar-l{display:flex;align-items:center;gap:10px}
        .topbar-logo{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#2563eb,#1e40af);display:flex;align-items:center;justify-content:center;color:#fff;box-shadow:0 2px 12px rgba(37,99,235,.3)}
        .topbar-name{font-weight:700;font-size:1rem;background:linear-gradient(135deg,#93c5fd,#22d3ee);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
        .topbar-menu{width:36px;height:36px;border-radius:10px;background:#0d2137;border:1px solid rgba(59,130,246,.12);display:flex;align-items:center;justify-content:center;color:#94a3b8;cursor:pointer;transition:.2s}
        .topbar-menu:hover{background:#112a45;color:#f0f4ff}
        .dropdown{position:relative;z-index:20;max-width:500px;margin:-4px auto 0;padding:0 16px;animation:dropIn .2s ease}
        @keyframes dropIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
        .dd-item{display:flex;align-items:center;gap:10px;padding:10px 14px;background:#0d2137;border:1px solid rgba(59,130,246,.12);color:#94a3b8;font-size:.8125rem;cursor:pointer;text-decoration:none;transition:.15s}
        .dd-item:first-child{border-radius:10px 10px 0 0}
        .dd-item:last-child{border-radius:0 0 10px 10px;border-top:none}
        .dd-item:hover{background:#112a45;color:#f0f4ff}
        .hero{text-align:center;padding:20px 0 28px;animation:fadeIn .5s ease}
        .hero-icon{position:relative;width:80px;height:80px;margin:0 auto 16px}
        .hero-glow{position:absolute;inset:-10px;border-radius:50%;background:radial-gradient(circle,rgba(59,130,246,.2) 0%,transparent 70%);animation:hGlow 3s ease-in-out infinite}
        @keyframes hGlow{0%,100%{opacity:.6;transform:scale(1)}50%{opacity:1;transform:scale(1.1)}}
        .hero-circle{position:relative;width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#1e40af);display:flex;align-items:center;justify-content:center;color:#fff;box-shadow:0 0 60px rgba(59,130,246,.4),inset 0 1px 0 rgba(255,255,255,.1)}
        .hero-title{font-size:2rem;font-weight:900;letter-spacing:-.02em;background:linear-gradient(135deg,#fff,#93c5fd,#22d3ee);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:6px}
        .hero-sub{color:#64748b;font-size:.8125rem;margin-bottom:12px}
        .h-badges{display:flex;align-items:center;justify-content:center;gap:6px}
        .badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:999px;font-size:.65rem;font-weight:600}
        .badge-b{color:#93c5fd;background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.2)}
        .badge-o{color:#64748b;background:transparent;border:1px solid rgba(100,116,139,.2)}
        .pulse-d{width:6px;height:6px;border-radius:50%;background:#4ade80;animation:dp 2s ease-in-out infinite}
        @keyframes dp{0%,100%{opacity:1}50%{opacity:.3}}
        .card{width:100%;background:#0d2137;border:1px solid rgba(59,130,246,.12);border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.3),0 0 60px rgba(59,130,246,.05);animation:slideUp .5s ease .1s both}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        @keyframes slideUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
        .tabs{display:flex;gap:4px;padding:8px;background:rgba(0,0,0,.2);border-bottom:1px solid rgba(59,130,246,.08)}
        .tab{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border-radius:10px;border:none;outline:none;font-family:'Inter',sans-serif;font-size:.8125rem;font-weight:600;cursor:pointer;transition:.2s;background:transparent;color:#475569}
        .tab-a{background:#1d4ed8;color:#fff;box-shadow:0 2px 8px rgba(29,78,216,.3)}
        .tab:not(.tab-a):hover{background:rgba(59,130,246,.1);color:#94a3b8}
        .panel{display:none;padding:20px}
        .panel-a{display:block;animation:pIn .25s ease}
        @keyframes pIn{from{opacity:0}to{opacity:1}}
        .step{display:none}
        .step-a{display:block;animation:sIn .3s ease}
        @keyframes sIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        .field{margin-bottom:16px}
        .field label{display:block;font-size:.6875rem;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px}
        .inp-wrap{position:relative}
        .inp-ico{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#475569;pointer-events:none}
        .inp{width:100%;height:48px;padding:0 14px 0 40px;background:#0a1929;border:1px solid rgba(59,130,246,.12);border-radius:12px;color:#f0f4ff;font-family:'JetBrains Mono',monospace;font-size:.875rem;outline:none;transition:.2s}
        .inp::placeholder{color:#475569;font-family:'Inter',sans-serif;font-size:.8125rem}
        .inp:focus{border-color:rgba(59,130,246,.5);box-shadow:0 0 0 3px rgba(59,130,246,.1)}
        .err-box{display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:10px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.15);color:#f87171;font-size:.8125rem;margin-bottom:12px}
        .btn-main{width:100%;height:48px;display:flex;align-items:center;justify-content:center;gap:8px;border-radius:12px;border:none;font-family:'Inter',sans-serif;font-size:.875rem;font-weight:700;letter-spacing:.04em;cursor:pointer;transition:.2s;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;box-shadow:0 4px 16px rgba(37,99,235,.25)}
        .btn-main:hover{background:linear-gradient(135deg,#3b82f6,#2563eb);box-shadow:0 6px 24px rgba(37,99,235,.35);transform:translateY(-1px)}
        .btn-main:active{transform:translateY(0)}
        .btn-main:disabled{opacity:.5;cursor:not-allowed;transform:none}
        .btn-sec{width:100%;height:44px;display:flex;align-items:center;justify-content:center;gap:8px;border-radius:12px;border:1px solid rgba(59,130,246,.12);background:transparent;color:#64748b;font-family:'Inter',sans-serif;font-size:.8125rem;font-weight:600;cursor:pointer;transition:.2s;margin-top:12px}
        .btn-sec:hover{background:#112a45;border-color:rgba(59,130,246,.2);color:#94a3b8}
        .load-c{text-align:center;padding:32px 0}
        .load-spin{position:relative;width:72px;height:72px;margin:0 auto 20px}
        .spin-ring{position:absolute;inset:0;border-radius:50%;border:3px solid transparent;border-top-color:#3b82f6;border-right-color:#3b82f6;animation:spin 1.2s linear infinite}
        @keyframes spin{to{transform:rotate(360deg)}}
        .spin-core{position:absolute;inset:8px;border-radius:50%;background:rgba(59,130,246,.1);display:flex;align-items:center;justify-content:center;color:#60a5fa}
        .load-t{font-weight:600;color:#94a3b8;font-size:.9375rem;margin-bottom:4px}
        .load-s{font-size:.75rem;color:#475569}
        .code-card{background:rgba(0,0,0,.25);border-radius:14px;padding:20px;border:1px solid rgba(59,130,246,.12);text-align:center;margin-bottom:16px}
        .code-h{display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:14px}
        .code-dot{width:8px;height:8px;border-radius:50%;background:#facc15;animation:dp 1.5s ease-in-out infinite}
        .code-st{font-size:.65rem;color:#facc15;text-transform:uppercase;letter-spacing:.12em;font-weight:600}
        .code-lbl{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.12em;margin-bottom:10px}
        .code-disp{font-family:'JetBrains Mono',monospace;font-size:2.25rem;font-weight:800;color:#60a5fa;letter-spacing:.25em;margin-bottom:14px;text-shadow:0 0 20px rgba(59,130,246,.3)}
        .btn-cp{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:8px;border:1px solid rgba(59,130,246,.12);background:rgba(59,130,246,.08);color:#94a3b8;font-family:'Inter',sans-serif;font-size:.75rem;font-weight:500;cursor:pointer;transition:.15s}
        .btn-cp:hover{background:rgba(59,130,246,.15);color:#93c5fd}
        .guide{text-align:left;margin-bottom:16px}
        .guide-t{font-size:.6875rem;color:#475569;font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px}
        .guide-s{display:flex;align-items:center;gap:10px;margin-bottom:8px}
        .guide-n{width:22px;height:22px;border-radius:50%;background:rgba(59,130,246,.15);display:flex;align-items:center;justify-content:center;font-size:.65rem;font-weight:700;color:#60a5fa;flex-shrink:0}
        .guide-s p{font-size:.8125rem;color:#64748b}
        .wait-bar{display:flex;align-items:center;justify-content:center;gap:8px;padding:10px;border-radius:10px;background:rgba(59,130,246,.05);border:1px solid rgba(59,130,246,.08)}
        .wait-spin{width:14px;height:14px;border:2px solid rgba(59,130,246,.15);border-top-color:#3b82f6;border-radius:50%;animation:spin 1s linear infinite}
        .wait-bar span{font-size:.8125rem;color:#475569}
        .suc-card{background:rgba(0,0,0,.2);border-radius:14px;padding:24px 20px;border:1px solid rgba(34,197,94,.15);text-align:center}
        .suc-ico{position:relative;width:64px;height:64px;margin:0 auto 14px}
        .suc-ping{position:absolute;inset:0;border-radius:50%;background:rgba(34,197,94,.15);animation:ping 2s cubic-bezier(0,0,.2,1) infinite}
        @keyframes ping{75%,100%{transform:scale(2);opacity:0}}
        .suc-circle{position:relative;width:64px;height:64px;border-radius:50%;background:rgba(34,197,94,.1);display:flex;align-items:center;justify-content:center;color:#4ade80;border:2px solid rgba(34,197,94,.2)}
        .suc-title{font-size:1.5rem;font-weight:900;color:#4ade80;letter-spacing:.04em;text-shadow:0 0 20px rgba(34,197,94,.2)}
        .suc-div{height:1px;background:rgba(59,130,246,.08);margin:16px 0}
        .suc-info{text-align:left}
        .info-r{display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:.8125rem;color:#94a3b8}
        .i-grn{color:#4ade80}.i-blu{color:#60a5fa}
        .info-r strong{color:#60a5fa;font-family:'JetBrains Mono',monospace;font-size:.75rem}
        .auth-sec{text-align:left}
        .auth-lbl{display:flex;align-items:center;justify-content:center;gap:5px;font-size:.625rem;color:#475569;text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px}
        .auth-box{background:rgba(0,0,0,.3);border-radius:10px;padding:10px 12px;border:1px solid rgba(59,130,246,.12);margin-bottom:8px;max-height:72px;overflow-y:auto}
        .auth-txt{font-family:'JetBrains Mono',monospace;font-size:.65rem;color:#64748b;word-break:break-all;line-height:1.6}
        .btn-cpa{width:100%;display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;border-radius:8px;border:1px solid rgba(34,197,94,.2);background:rgba(34,197,94,.08);color:#4ade80;font-family:'Inter',sans-serif;font-size:.75rem;font-weight:600;cursor:pointer;transition:.15s}
        .btn-cpa:hover{background:rgba(34,197,94,.15)}
        .deploy{display:flex;align-items:center;gap:12px;padding:14px;border-radius:10px;background:linear-gradient(135deg,rgba(59,130,246,.1),rgba(6,182,212,.08));border:1px solid rgba(59,130,246,.12);text-align:left}
        .deploy-ico{font-size:1.5rem;flex-shrink:0}
        .deploy-t{font-size:.8125rem;font-weight:800;color:#93c5fd;letter-spacing:.02em}
        .deploy-d{font-size:.6875rem;color:#475569;margin-top:2px}
        .con-sec{width:100%;margin-top:16px}
        .con-card{background:rgba(0,0,0,.3);border:1px solid rgba(59,130,246,.08);border-radius:12px;padding:12px}
        .con-h{display:flex;align-items:center;gap:6px;margin-bottom:8px;color:#4ade80;font-family:'JetBrains Mono',monospace;font-size:.6875rem}
        .con-logs{max-height:120px;overflow-y:auto}
        .con-logs p{font-family:'JetBrains Mono',monospace;font-size:.625rem;color:#475569;line-height:1.7}
        .feats{width:100%;display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:20px}
        .feat{background:#0d2137;border:1px solid rgba(59,130,246,.08);border-radius:12px;padding:14px 8px;text-align:center;color:#475569;transition:.2s}
        .feat:hover{border-color:rgba(59,130,246,.12);color:#64748b}
        .feat-l{font-size:.6875rem;font-weight:600;color:#64748b;margin-top:6px}
        .footer{margin-top:28px;text-align:center;padding-bottom:16px}
        .footer p{font-size:.65rem;color:rgba(100,116,139,.5)}
        .footer p+p{margin-top:3px}
        .modal{position:fixed;inset:0;z-index:100;background:rgba(0,0,0,.6);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:20px;animation:mIn .2s ease}
        @keyframes mIn{from{opacity:0}to{opacity:1}}
        .modal-c{width:100%;max-width:360px;background:#0d2137;border:1px solid rgba(59,130,246,.12);border-radius:16px;overflow:hidden}
        .modal-h{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid rgba(59,130,246,.08)}
        .modal-h h3{font-size:.9375rem;font-weight:700}
        .modal-x{width:32px;height:32px;border-radius:8px;background:transparent;border:none;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center}
        .modal-x:hover{background:rgba(255,255,255,.05);color:#f0f4ff}
        .modal-b{padding:20px}
        .modal-b p{font-size:.8125rem;color:#94a3b8;margin-bottom:6px}
        .hid{display:none!important}
        .qr-cs{text-align:center;padding:48px 0}
        .qr-cs svg{color:#475569;margin-bottom:16px}
        .qr-t{font-size:1rem;font-weight:700;color:#94a3b8;margin-bottom:6px}
        .qr-d{font-size:.8125rem;color:#475569}
        @media(max-width:480px){.wrap{padding:0 12px 20px}.hero-title{font-size:1.75rem}.code-disp{font-size:1.75rem}.panel{padding:16px}}
    </style>
</head>
<body>
    <!-- Background -->
    <div class="bg-fx">
        <div class="orb orb1"></div>
        <div class="orb orb2"></div>
        <div class="orb orb3"></div>
    </div>

    <!-- Topbar -->
    <nav class="topbar">
        <div class="topbar-l">
            <div class="topbar-logo">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
            </div>
            <span class="topbar-name">TOXIC YOBBY</span>
        </div>
        <button class="topbar-menu" id="menuBtn">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
        </button>
    </nav>

    <!-- Dropdown -->
    <div class="dropdown hid" id="dropdown">
        <a href="https://t.me/Yobby0" target="_blank" rel="noopener noreferrer" class="dd-item">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
            Yobby_txc
        </a>
        <div class="dd-item" id="aboutBtn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
            About
        </div>
    </div>

    <div class="wrap">
        <!-- Hero -->
        <div class="hero">
            <div class="hero-icon">
                <div class="hero-glow"></div>
                <div class="hero-circle">
                    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="11" width="18" height="10" rx="2"></rect><circle cx="12" cy="16" r="1"></circle><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                </div>
            </div>
            <h1 class="hero-title">TOXIC YOBBY</h1>
            <p class="hero-sub">Link your WhatsApp — get your Session ID instantly</p>
            <div class="h-badges">
                <span class="badge badge-b"><span class="pulse-d"></span> Live</span>
                <span class="badge badge-o">v4.0.0</span>
                <span class="badge badge-o">E2E</span>
            </div>
        </div>

        <!-- Main Card -->
        <div class="card">
            <!-- Tabs -->
            <div class="tabs">
                <button class="tab tab-a" id="tabPair">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>
                    Pair Code
                </button>
                <button class="tab" id="tabQr">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                    QR Code
                </button>
            </div>

            <!-- Pair Code Panel -->
            <div class="panel panel-a" id="panelPair">
                <!-- IDLE -->
                <div class="step step-a" id="stepIdle">
                    <div class="field">
                        <label>Phone Number</label>
                        <div class="inp-wrap">
                            <svg class="inp-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                            <input type="text" class="inp" id="phoneInput" placeholder="e.g. 254712345678 (no +)">
                        </div>
                    </div>
                    <div class="err-box hid" id="errBox">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                        <span id="errMsg"></span>
                    </div>
                    <button class="btn-main" id="pairBtn" disabled>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
                        GET PAIR CODE
                    </button>
                </div>

                <!-- REQUESTING -->
                <div class="step" id="stepRequesting">
                    <div class="load-c">
                        <div class="load-spin">
                            <div class="spin-ring"></div>
                            <div class="spin-core"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.55a11 11 0 0 1 14.08 0"></path><path d="M1.42 9a16 16 0 0 1 21.16 0"></path><path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path><line x1="12" y1="20" x2="12.01" y2="20"></line></svg></div>
                        </div>
                        <p class="load-t">Connecting to WhatsApp...</p>
                        <p class="load-s">This may take 10-25 seconds</p>
                    </div>
                </div>

                <!-- PAIRING -->
                <div class="step" id="stepPairing">
                    <div class="code-card">
                        <div class="code-h">
                            <span class="code-dot"></span>
                            <span class="code-st">Waiting for connection</span>
                        </div>
                        <p class="code-lbl">Your Pairing Code</p>
                        <div class="code-disp" id="codeDisplay">----</div>
                        <button class="btn-cp" id="copyCodeBtn">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                            Copy Code
                        </button>
                    </div>
                    <div class="guide">
                        <p class="guide-t">How to link:</p>
                        <div class="guide-s"><span class="guide-n">1</span><p>Open WhatsApp on your phone</p></div>
                        <div class="guide-s"><span class="guide-n">2</span><p>Go to Settings &rarr; Linked Devices</p></div>
                        <div class="guide-s"><span class="guide-n">3</span><p>Tap "Link a Device"</p></div>
                        <div class="guide-s"><span class="guide-n">4</span><p>Enter the pairing code above</p></div>
                    </div>
                    <div class="wait-bar">
                        <div class="wait-spin"></div>
                        <span>Waiting for you to enter the code...</span>
                    </div>
                </div>

                <!-- CONNECTED -->
                <div class="step" id="stepConnected">
                    <div class="suc-card">
                        <div class="suc-ico">
                            <div class="suc-ping"></div>
                            <div class="suc-circle"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></div>
                        </div>
                        <h2 class="suc-title">BOT CONNECTED!</h2>
                        <div class="suc-div"></div>
                        <div class="suc-info">
                            <div class="info-r"><svg class="i-grn" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg><span>Device linked successfully</span></div>
                            <div class="info-r"><svg class="i-grn" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg><span>Session ID sent to WhatsApp</span></div>
                            <div class="info-r"><svg class="i-blu" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg><span>Session: <strong id="sessionDisplay"></strong></span></div>
                        </div>
                        <div class="suc-div"></div>
                        <div class="auth-sec">
                            <p class="auth-lbl"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>Auth Credentials</p>
                            <div class="auth-box"><p class="auth-txt" id="authDisplay">Loading...</p></div>
                            <button class="btn-cpa" id="copyAuthBtn">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                                Copy Credentials
                            </button>
                        </div>
                        <div class="suc-div"></div>
                        <div class="deploy">
                            <div class="deploy-ico">&#128640;</div>
                            <div><p class="deploy-t">DEPLOY TOXIC BOT NOW!</p><p class="deploy-d">Copy the Session ID from your WhatsApp and use it to deploy</p></div>
                        </div>
                    </div>
                    <button class="btn-sec" id="resetBtn">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
                        Pair Another Device
                    </button>
                </div>
            </div>

            <!-- QR Panel -->
            <div class="panel" id="panelQr">
                <div class="qr-cs">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                    <p class="qr-t">QR Code Coming Soon</p>
                    <p class="qr-d">Use Pair Code method for now — it's faster and more secure</p>
                </div>
            </div>
        </div>

        <!-- Console -->
        <div class="con-sec hid" id="consoleSec">
            <div class="con-card">
                <div class="con-h"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg><span>Console</span></div>
                <div class="con-logs" id="consoleLogs"></div>
            </div>
        </div>

        <!-- Features -->
        <div class="feats">
            <div class="feat"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg><p class="feat-l">Encrypted</p></div>
            <div class="feat"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg><p class="feat-l">Cloud</p></div>
            <div class="feat"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg><p class="feat-l">Instant</p></div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>TOXIC YOBBY pair 1 — v4.0.0 (PHP)</p>
            <p>Developed by t.me/Yobby0</p>
        </div>
    </div>

    <!-- About Modal -->
    <div class="modal hid" id="aboutModal">
        <div class="modal-c">
            <div class="modal-h"><h3>About TOXIC YOBBY</h3><button class="modal-x" id="closeModal"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button></div>
            <div class="modal-b">
                <p>TOXIC YOBBY v4.0.0</p>
                <p>The best new WhatsApp Bot</p>
                <p>Powered by mrxd-baileys API</p>
                <p>E2E Encrypted &bull; Pairing Code Auth</p>
                <p>Anti-Call &bull; Anti-Demote &bull; Always Online</p>
                <a href="https://t.me/Yobby0" target="_blank" rel="noopener noreferrer" style="display:block;margin-top:14px;padding:10px;border-radius:10px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;text-align:center;font-weight:700;font-size:.8125rem;text-decoration:none;letter-spacing:.04em">Yobby_txc</a>
            </div>
        </div>
    </div>

    <script>
        // State
        let currentStep = 'idle';
        let sessionId = '';
        let pairingCode = '';
        let authState = '';
        let pollTimer = null;

        // Elements
        const $ = id => document.getElementById(id);
        const phoneInput = $('phoneInput');
        const pairBtn = $('pairBtn');
        const errBox = $('errBox');
        const errMsg = $('errMsg');
        const codeDisplay = $('codeDisplay');
        const sessionDisplay = $('sessionDisplay');
        const authDisplay = $('authDisplay');
        const consoleLogs = $('consoleLogs');

        // Steps
        const steps = {
            idle: $('stepIdle'),
            requesting: $('stepRequesting'),
            pairing: $('stepPairing'),
            connected: $('stepConnected'),
        };

        function setStep(step) {
            Object.values(steps).forEach(s => s.classList.remove('step-a'));
            if (steps[step]) steps[step].classList.add('step-a');
            currentStep = step;
        }

        function addLog(msg) {
            const p = document.createElement('p');
            p.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
            consoleLogs.appendChild(p);
            $('consoleSec').classList.remove('hid');
        }

        function showError(msg) {
            errMsg.textContent = msg;
            errBox.classList.remove('hid');
        }

        function hideError() {
            errBox.classList.add('hid');
        }

        // Phone input
        phoneInput.addEventListener('input', () => {
            phoneInput.value = phoneInput.value.replace(/[^0-9]/g, '');
            pairBtn.disabled = !phoneInput.value.trim();
        });

        phoneInput.addEventListener('keydown', e => {
            if (e.key === 'Enter' && phoneInput.value.trim()) requestPairing();
        });

        // Tabs
        $('tabPair').addEventListener('click', () => {
            $('tabPair').classList.add('tab-a');
            $('tabQr').classList.remove('tab-a');
            $('panelPair').classList.add('panel-a');
            $('panelQr').classList.remove('panel-a');
        });

        $('tabQr').addEventListener('click', () => {
            $('tabQr').classList.add('tab-a');
            $('tabPair').classList.remove('tab-a');
            $('panelQr').classList.add('panel-a');
            $('panelPair').classList.remove('panel-a');
        });

        // Menu
        $('menuBtn').addEventListener('click', () => {
            $('dropdown').classList.toggle('hid');
        });

        // About
        $('aboutBtn').addEventListener('click', () => {
            $('aboutModal').classList.remove('hid');
            $('dropdown').classList.add('hid');
        });

        $('closeModal').addEventListener('click', () => {
            $('aboutModal').classList.add('hid');
        });

        $('aboutModal').addEventListener('click', e => {
            if (e.target === $('aboutModal')) $('aboutModal').classList.add('hid');
        });

        // Copy code
        $('copyCodeBtn').addEventListener('click', () => {
            if (!pairingCode) return;
            navigator.clipboard.writeText(pairingCode);
            $('copyCodeBtn').innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg> Copied!';
            setTimeout(() => {
                $('copyCodeBtn').innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy Code';
            }, 2000);
        });

        // Copy auth
        $('copyAuthBtn').addEventListener('click', () => {
            if (!authState) return;
            navigator.clipboard.writeText(authState);
            $('copyAuthBtn').innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg> Copied!';
            setTimeout(() => {
                $('copyAuthBtn').innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy Credentials';
            }, 2000);
        });

        // Reset
        $('resetBtn').addEventListener('click', () => {
            if (pollTimer) clearInterval(pollTimer);
            setStep('idle');
            pairingCode = '';
            sessionId = '';
            authState = '';
            phoneInput.value = '';
            codeDisplay.textContent = '----';
            hideError();
            addLog('Session reset');
        });

        // Request pairing
        async function requestPairing() {
            const phone = phoneInput.value.trim();
            if (!phone) { showError('Enter your WhatsApp number'); return; }
            hideError();
            setStep('requesting');
            addLog('Connecting to WhatsApp servers...');

            try {
                const res = await fetch('api/pair.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ phoneNumber: phone }),
                });
                const data = await res.json();

                if (data.success) {
                    sessionId = data.sessionId;
                    pairingCode = data.pairingCode || '';
                    addLog('Session: ' + sessionId);
                    if (pairingCode) {
                        codeDisplay.textContent = pairingCode;
                        addLog('Pairing Code: ' + pairingCode);
                        addLog('Open WhatsApp > Settings > Linked Devices > Link a Device');
                    } else {
                        addLog('Waiting for pairing code...');
                    }
                    setStep('pairing');
                    startPolling();
                } else {
                    showError(data.error || 'Failed to get pairing code');
                    setStep('idle');
                    addLog('Failed: ' + (data.error || 'Unknown error'));
                }
            } catch (err) {
                showError('Network error. Try again.');
                setStep('idle');
                addLog('Network error');
            }
        }

        // Polling
        function startPolling() {
            if (pollTimer) clearInterval(pollTimer);
            pollTimer = setInterval(async () => {
                if (!sessionId) return;
                try {
                    const res = await fetch(`api/status.php?sessionId=${encodeURIComponent(sessionId)}`);
                    const data = await res.json();

                    if (data.success) {
                        if (data.pairingCode && !pairingCode) {
                            pairingCode = data.pairingCode;
                            codeDisplay.textContent = pairingCode;
                            addLog('Pairing Code: ' + pairingCode);
                            addLog('Open WhatsApp > Settings > Linked Devices > Link a Device');
                        }
                        if (data.status === 'connected' && data.authState) {
                            authState = data.authState;
                            sessionDisplay.textContent = sessionId;
                            authDisplay.textContent = authState;
                            setStep('connected');
                            addLog('BOT CONNECTED!');
                            addLog('Session ID sent to your WhatsApp!');
                            clearInterval(pollTimer);
                        }
                        if (data.status === 'error') {
                            showError('Pairing failed. Try again.');
                            setStep('idle');
                            addLog('Pairing error');
                            clearInterval(pollTimer);
                        }
                    }
                } catch {}
            }, 3000);
        }

        pairBtn.addEventListener('click', requestPairing);
    </script>
</body>
</html>
