<?php
/**
 * TOXIC YOBBY - Pair API
 * Starts a WhatsApp pairing session by spawning Node.js in background
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$phoneNumber = isset($input['phoneNumber']) ? preg_replace('/[^0-9]/', '', $input['phoneNumber']) : '';

if (!$phoneNumber || strlen($phoneNumber) < 10) {
    echo json_encode(['success' => false, 'error' => 'Invalid phone number. Include country code without +']);
    exit;
}

// Generate session ID
function generateCoolCode() {
    $prefixes = ['TOX', 'TXC', 'KNG', 'BOT', 'ZAP', 'FLX', 'VPR', 'RDX', 'NVA', 'PKD', 'SNK', 'DRG', 'PHX', 'MTX'];
    $suffixes = ['KING', 'QUEEN', 'BOSS', 'GOD', 'ACE', 'PRO', 'MAX', 'LORD', 'TITAN', 'DEMON', 'GHOST', 'HAWK', 'WOLF', 'FURY', 'BLITZ', 'STORM', 'FLAME', 'FROST', 'VENOM', 'BLAZE', 'NEXUS'];
    $mids = ['C', 'X', 'Z', 'V', 'N', 'K', 'R', 'T', 'S', 'M'];
    $prefix = $prefixes[array_rand($prefixes)];
    $mid = $mids[array_rand($mids)];
    $suffix = $suffixes[array_rand($suffixes)];
    return $prefix . $mid . $suffix;
}

$sessionId = generateCoolCode();

// Create session directory
$sessionDir = __DIR__ . '/../sessions';
if (!is_dir($sessionDir)) {
    mkdir($sessionDir, 0755, true);
}

// Write initial session status
$sessionFile = $sessionDir . '/' . $sessionId . '.json';
$initialData = [
    'status' => 'connecting',
    'sessionId' => $sessionId,
    'phoneNumber' => $phoneNumber,
    'pairingCode' => null,
    'authState' => null,
    'createdAt' => date('c'),
];
file_put_contents($sessionFile, json_encode($initialData));

// Spawn Node.js background process for Baileys connection
$nodeScript = __DIR__ . '/../server.js';
$nodePath = trim(shell_exec('which node') ?: 'node');
$logFile = $sessionDir . '/' . $sessionId . '.log';

$cmd = sprintf(
    '%s %s %s %s > %s 2>&1 &',
    escapeshellcmd($nodePath),
    escapeshellarg($nodeScript),
    escapeshellarg($sessionId),
    escapeshellarg($phoneNumber),
    escapeshellarg($logFile)
);

exec($cmd);

// Wait a bit and check if pairing code was generated quickly
usleep(2000000); // 2 seconds

$checkData = json_decode(file_get_contents($sessionFile), true);
$pairingCode = isset($checkData['pairingCode']) ? $checkData['pairingCode'] : null;

echo json_encode([
    'success' => true,
    'pairingCode' => $pairingCode,
    'sessionId' => $sessionId,
    'message' => $pairingCode
        ? 'Enter this pairing code in WhatsApp > Settings > Linked Devices > Link a Device'
        : 'Session started. Check status for pairing code.',
]);
