<?php
/**
 * TOXIC YOBBY - Status API
 * Checks the pairing session status from JSON file
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$sessionId = isset($_GET['sessionId']) ? preg_replace('/[^a-zA-Z0-9]/', '', $_GET['sessionId']) : '';

if (!$sessionId) {
    echo json_encode(['success' => false, 'error' => 'Session ID is required']);
    exit;
}

$sessionFile = __DIR__ . '/../sessions/' . $sessionId . '.json';

if (!file_exists($sessionFile)) {
    echo json_encode(['success' => false, 'error' => 'Session not found', 'status' => 'not_found']);
    exit;
}

$data = json_decode(file_get_contents($sessionFile), true);

if (!$data) {
    echo json_encode(['success' => false, 'error' => 'Invalid session data']);
    exit;
}

echo json_encode([
    'success' => true,
    'status' => $data['status'] ?? 'unknown',
    'pairingCode' => $data['pairingCode'] ?? null,
    'authState' => $data['authState'] ?? null,
    'sessionId' => $data['sessionId'] ?? $sessionId,
]);
