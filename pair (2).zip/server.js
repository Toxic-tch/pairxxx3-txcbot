/**
 * TOXIC YOBBY v4.0.0 — PHP Pair Backend (Node.js Baileys Worker)
 * Spawned by PHP api/pair.php — connects to WhatsApp, generates pairing code,
 * writes status to sessions/<sessionId>.json
 *
 * Usage: node server.js <sessionId> <phoneNumber>
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  BufferJSON,
  Browsers,
} = require('mrxd-baileys');

const P = require('pino');
const fs = require('fs');
const path = require('path');
const os = require('os');

const logger = P({ level: 'silent' });

// ─── Args ───
const sessionId = process.argv[2];
const phoneNumber = process.argv[3];

if (!sessionId || !phoneNumber) {
  console.error('Usage: node server.js <sessionId> <phoneNumber>');
  process.exit(1);
}

const sessionsDir = path.join(__dirname, 'sessions');
const sessionFile = path.join(sessionsDir, `${sessionId}.json`);

// ─── Helpers ───
function updateSession(updates) {
  try {
    let data = {};
    if (fs.existsSync(sessionFile)) {
      data = JSON.parse(fs.readFileSync(sessionFile, 'utf8'));
    }
    data = { ...data, ...updates, updatedAt: new Date().toISOString() };
    fs.writeFileSync(sessionFile, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('[SESSION] Write error:', e.message);
  }
}

function formatPairingCode(code) {
  if (!code) return '';
  if (code.length === 8) return `${code.slice(0, 4)}-${code.slice(4)}`;
  return code;
}

function serializeAuthState(state) {
  try {
    const jsonStr = JSON.stringify(state, BufferJSON.replacer);
    const base64 = Buffer.from(jsonStr).toString('base64');
    return `TO•XI•C_B•O•T:~${base64}`;
  } catch (e) {
    console.error('[SERIALIZE] Error:', e);
    return '';
  }
}

async function sendSessionToWhatsApp(socket, phone, authStateBase64) {
  const jid = phone + '@s.whatsapp.net';
  const delay = (ms) => new Promise(r => setTimeout(r, ms));

  try {
    await socket.sendMessage(jid, { text: authStateBase64 });
    console.log(`[PAIR] Session ID sent to WhatsApp ${jid}`);
    await delay(1500);
    await socket.sendMessage(jid, { text: '✅ BOT CONNECTED!\n\n🚀 DEPLOY TOXIC BOT NOW!\n\nCopy the Session ID above and use it to deploy your bot on control.bot-hosting.net' });
    console.log(`[PAIR] Connected message sent to WhatsApp ${jid}`);
  } catch (sendErr) {
    console.error('[PAIR] Send failed:', sendErr?.message);
    try {
      await delay(3000);
      await socket.sendMessage(jid, { text: authStateBase64 });
      await delay(1500);
      await socket.sendMessage(jid, { text: '✅ BOT CONNECTED!\n\n🚀 DEPLOY TOXIC BOT NOW!' });
      console.log(`[PAIR] Session ID sent (retry) to WhatsApp ${jid}`);
    } catch (retryErr) {
      console.error('[PAIR] Retry failed:', retryErr?.message);
    }
  }
}

// ─── Main ───
async function main() {
  console.log(`[PAIR] Starting Baileys for session ${sessionId}, phone ${phoneNumber}`);

  const sessionDir = path.join(os.tmpdir(), `toxic_php_${sessionId}_${Date.now()}`);
  fs.mkdirSync(sessionDir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const socket = makeWASocket({
    auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
    printQRInTerminal: false,
    logger,
    browser: Browsers.ubuntu('Chrome'),
    connectTimeoutMs: 60_000,
    defaultQueryTimeoutMs: 60_000,
    qrTimeout: 60_000,
  });

  socket.ev.on('creds.update', saveCreds);

  socket.ev.on('connection.update', async (update) => {
    try {
      const { connection, lastDisconnect, qr } = update;

      // Wait for QR before requesting pairing code
      if (qr) {
        console.log(`[PAIR] QR received for ${sessionId}, requesting pairing code...`);
        try {
          const rawCode = await socket.requestPairingCode(phoneNumber);
          const code = formatPairingCode(rawCode);
          console.log(`[PAIR] Code: ${code} for ${sessionId}`);
          updateSession({ status: 'pairing', pairingCode: code });
        } catch (pairError) {
          console.error('[PAIR] Code request failed:', pairError?.message);
          updateSession({ status: 'error' });
        }
      }

      if (connection === 'open') {
        console.log(`[PAIR] Device linked for ${sessionId}!`);
        const authStateBase64 = serializeAuthState(state);
        updateSession({ status: 'connected', authState: authStateBase64 });

        // Send Session ID to WhatsApp
        await sendSessionToWhatsApp(socket, phoneNumber, authStateBase64);

        // Close socket after sending
        setTimeout(() => { try { socket.end(undefined); } catch {} }, 5000);

        // Cleanup: remove session file after 5 minutes
        setTimeout(() => {
          try { fs.unlinkSync(sessionFile); } catch {}
          try { fs.rmSync(sessionDir, { recursive: true, force: true }); } catch {}
        }, 300000);
      }

      if (connection === 'close') {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const data = JSON.parse(fs.readFileSync(sessionFile, 'utf8').replace(/^\uFEFF/, ''));
        if (data.status !== 'connected') {
          if (statusCode === 515 || statusCode === 428) {
            console.log(`[PAIR] Restart required for ${sessionId}...`);
            updateSession({ status: 'connecting' });
          } else {
            updateSession({ status: 'disconnected' });
          }
        }
      }
    } catch {}
  });

  console.log(`[PAIR] Socket created for ${sessionId}, waiting for QR event...`);

  // Timeout: if not connected in 90 seconds, mark as error
  setTimeout(() => {
    try {
      const data = JSON.parse(fs.readFileSync(sessionFile, 'utf8'));
      if (data.status !== 'connected') {
        updateSession({ status: 'error' });
        console.log(`[PAIR] Timeout for ${sessionId}`);
        try { socket.end(undefined); } catch {}
      }
    } catch {}
  }, 90000);
}

// Error handlers
process.on('uncaughtException', (error) => {
  console.error('[TOXIC-PHP] Uncaught exception:', error?.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('[TOXIC-PHP] Unhandled rejection:', String(reason));
});

main().catch(e => {
  console.error('[PAIR] Fatal:', e?.message);
  updateSession({ status: 'error' });
  process.exit(1);
});
